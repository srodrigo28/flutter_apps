package com.pedromassango.my_flutter_challenges

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
