import 'package:flutter/material.dart';

import 'banking_app.dart';

void main() {
  runApp(
    MaterialApp(
      debugShowCheckedModeBanner: false,
      home: BankApp(),
    ),
  );
}
