class Titulo {
  String id;
  String campeonato;
  String ano;

  Titulo({this.id, this.campeonato, this.ano});
}
