package com.example.flutter_aula1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
