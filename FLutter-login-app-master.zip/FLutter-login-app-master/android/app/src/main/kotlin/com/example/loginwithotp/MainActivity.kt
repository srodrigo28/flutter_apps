package com.example.loginwithotp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
