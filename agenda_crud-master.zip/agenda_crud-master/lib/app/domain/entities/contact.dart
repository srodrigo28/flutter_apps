
class Contact{
  dynamic id;
  String nome;
  String telefone; 
  String email; 
  String urlAvatar;

  Contact({this.id,this.nome,this.telefone,this.email,this.urlAvatar});
  }
