package br.com.helio.agenda_crud

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
